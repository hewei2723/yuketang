from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO

import base64
import binascii
import requests
import json

iv = b'0902030405060908'
key = b'0102030405060908'


def encrypt(plaintext):
    aes = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = aes.encrypt(pad(plaintext, AES.block_size))
    return binascii.hexlify(ciphertext).decode('utf-8')


def decrypt(ciphertext):
    aes = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(aes.decrypt(binascii.unhexlify(ciphertext)), AES.block_size)
    return plaintext.decode('utf-8')


def getPopulationInfo(encryptedIdCard):
    url = 'https://www.btjzz.top/api/sms/ldrkxxCk'
    headers = {'Content-Type': 'application/json'}

    response = requests.post(url, headers=headers, data=encryptedIdCard)
    response_json = response.json()

    if response_json['succ']:
        return response_json['data']
    else:
        return response_json['msg']


def nation_to_chinese(code):
    nation_map = {
        '01': '汉',
        '02': '蒙古',
        '03': '回',
        '04': '藏',
        '05': '维吾尔',
        '06': '苗',
        '07': '彝',
        '08': '壮',
        '09': '布依',
        '10': '朝鲜',
        '11': '满',
        '12': '侗',
        '13': '瑶',
        '14': '白',
        '15': '土家',
        '16': '哈尼',
        '17': '哈萨克',
        '18': '傣',
        '19': '黎',
        '20': '傈僳',
        '21': '佤',
        '22': '畲',
        '23': '高山',
        '24': '拉祜',
        '25': '水',
        '26': '东乡',
        '27': '纳西',
        '28': '景颇',
        '29': '柯尔克孜',
        '30': '土',
        '31': '达斡尔',
        '32': '仫佬',
        '33': '羌',
        '34': '布朗',
        '35': '撒拉',
        '36': '毛南',
        '37': '仡佬',
        '38': '锡伯',
        '39': '阿昌',
        '40': '普米',
        '41': '塔吉克',
        '42': '怒',
        '43': '乌孜别克',
        '44': '俄罗斯',
        '45': '鄂温克',
        '46': '德昂',
        '47': '保安',
        '48': '裕固',
        '49': '京',
        '50': '塔塔尔',
        '51': '独龙',
        '52': '鄂伦春',
        '53': '赫哲',
        '54': '门巴',
        '55': '珞巴',
        '56': '基诺'
    }

    return nation_map.get(code, '')


def gender_to_chinese(code):
    gender_map = {
        '1': '男',
        '2': '女'
    }

    return gender_map.get(code, '')


def gen_idcard_png(name, address, gender, nation, idcard, photo_base64):
    template = Image.open("temp.png")

    draw = ImageDraw.Draw(template)

    font = ImageFont.truetype("font.otf", 28)

    draw.text((490, 241), name, font=font, fill=(0, 0, 0))
    draw.text((490, 299), gender, font=font, fill=(0, 0, 0))
    draw.text((626, 299), nation, font=font, fill=(0, 0, 0))
    draw.text((490, 360), address, font=font, fill=(0, 0, 0))
    draw.text((618, 418), idcard, font=font, fill=(0, 0, 0))

    photo_data = base64.b64decode(photo_base64)
    photo = Image.open(BytesIO(photo_data))

    photo = photo.resize((286, 352), Image.LANCZOS)

    template.paste(photo, (100, 180))

    template.save(name + "-" + idCard + ".png")
    print("图片已保存")


if 1 == 1:
    idCard = input("请输入身份证：")
    encryptedIdCard = encrypt(idCard.encode('utf-8')).upper()
    result = getPopulationInfo(encryptedIdCard)
    decryptedResult = decrypt(result)
    jsonObj = json.loads(decryptedResult)

    name = jsonObj['xm']
    address = jsonObj['hjdzQhnxxdz']
    sexCode = jsonObj['xbdm']
    nationCode = jsonObj['mzdm']
    photo_base64 = jsonObj['xp']

    sex = gender_to_chinese(sexCode)
    nation = nation_to_chinese(nationCode)

    gen_idcard_png(name, address, sex, nation, idCard, photo_base64)
    print(address)
    print("查询成功，信息为：" + name + "-" + idCard)